# main.py
from operations.add_book import add_book
from operations.register_member import register_member
from operations.borrow_book import borrow_book
from operations.return_book import return_book
from operations.list_books import list_books

def menu():
    print("\n===== Library System Menu =====")
    print("1. Add Book")
    print("2. Register Member")
    print("3. Borrow Book")
    print("4. Return Book")
    print("5. List All Books")
    print("6. Exit")

def run():
    while True:
        menu()
        choice = input("Enter your choice (1–6): ").strip()

        if choice == "1":
            bid = input("Enter Book ID: ").strip()
            title = input("Enter Book Title: ").strip()
            author = input("Enter Author Name: ").strip()
            print(add_book(bid, title, author))

        elif choice == "2":
            mid = input("Enter Member ID: ").strip()
            name = input("Enter Member Name: ").strip()
            print(register_member(mid, name))

        elif choice == "3":
            bid = input("Enter Book ID to borrow: ").strip()
            mid = input("Enter Member ID: ").strip()
            print(borrow_book(bid, mid))

        elif choice == "4":
            bid = input("Enter Book ID to return: ").strip()
            print(return_book(bid))

        elif choice == "5":
            print("\n--- Library Books ---")
            print(list_books())

        elif choice == "6":
            print("Exiting the Library System. Goodbye!")
            break

        else:
            print("Invalid choice. Please enter a number from 1 to 6.")

if __name__ == "__main__":
    run()

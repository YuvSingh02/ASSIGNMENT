# models/book.py

class Book:
    def __init__(self, book_id, title, author):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.available = True
        self.borrower = None

    def __str__(self):
        status = "Available" if self.available else f"Borrowed by {self.borrower}"
        return f"{self.book_id} | {self.title} by {self.author} - {status}"

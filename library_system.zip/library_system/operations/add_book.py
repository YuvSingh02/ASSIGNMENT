#operations/add_book.py


from models.book import Book
from storage.library_data import books

def add_book(book_id, title, author):
    if book_id in books:
        return "Book ID already exists."
    books[book_id] = Book(book_id, title, author)
    return "Book added successfully."# 

# operations/borrow_book.py

from storage.library_data import books, members

def borrow_book(book_id, member_id):
    if book_id not in books:
        return "Book not found."
    if member_id not in members:
        return "Member not found."
    book = books[book_id]
    if not book.available:
        return "Book is already borrowed."
    book.available = False
    book.borrower = members[member_id].name
    return f"{book.title} has been borrowed by {book.borrower}."

# operations/list_books.py

from storage.library_data import books

def list_books():
    if not books:
        return "No books available."
    return "\n".join(str(book) for book in books.values())

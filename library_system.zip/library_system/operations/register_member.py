# operations/register_member.py

from models.member import Member
from storage.library_data import members

def register_member(member_id, name):
    if member_id in members:
        return "Member ID already exists."
    members[member_id] = Member(member_id, name)
    return "Member registered successfully."

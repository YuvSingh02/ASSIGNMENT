# operations/return_book.py

from storage.library_data import books

def return_book(book_id):
    if book_id not in books:
        return "Book not found."
    book = books[book_id]
    if book.available:
        return "Book was not borrowed."
    borrower = book.borrower
    book.available = True
    book.borrower = None
    return f"{book.title} has been returned by {borrower}."

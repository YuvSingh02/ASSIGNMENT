# storage/library_data.py
from models.book import Book
from models.member import Member  # only if you want to pre-add members too

books = {
    "B001": Book("B001", "The Alchemist", "Paulo Coelho"),
    "B002": Book("B002", "1984", "George Orwell"),
    "B003": Book("B003", "Clean Code", "Robert C. Martin")
}

from models.member import Member

members = {
    "M001": Member("M001", "Yuvraj"),
    "M002": Member("M002", "Aryan"),
}

